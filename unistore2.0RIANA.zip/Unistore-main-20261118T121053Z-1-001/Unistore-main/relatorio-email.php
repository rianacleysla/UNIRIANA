<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php?redirecionar=relatorio-email.php');
    exit;
}

use PHPMailer\PHPMailer\PHPMailer;

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/includes/relatorio-pdf.php';

$configuracaoLocal = __DIR__ . '/smtp.local.php';
$smtpLocal = is_file($configuracaoLocal) ? require $configuracaoLocal : [];
$smtpLocal = is_array($smtpLocal) ? $smtpLocal : [];
$smtpHost = getenv('UNISTORE_SMTP_HOST') ?: ($smtpLocal['host'] ?? '');
$smtpUsuario = getenv('UNISTORE_SMTP_USER') ?: ($smtpLocal['username'] ?? '');
$smtpSenha = getenv('UNISTORE_SMTP_PASS') ?: ($smtpLocal['password'] ?? '');
$smtpSenha = preg_replace('/\s+/', '', $smtpSenha);
$smtpRemetente = 'rianacleysla@gmail.com';
$smtpPorta = (int) (getenv('UNISTORE_SMTP_PORT') ?: ($smtpLocal['port'] ?? 587));
$smtpCriptografia = strtolower(getenv('UNISTORE_SMTP_SECURE') ?: ($smtpLocal['secure'] ?? 'tls'));
$smtpConfigurado = $smtpHost !== '' && $smtpUsuario !== '' && $smtpSenha !== ''
    && $smtpRemetente !== '' && filter_var($smtpRemetente, FILTER_VALIDATE_EMAIL)
    && $smtpPorta > 0 && in_array($smtpCriptografia, ['tls', 'ssl'], true);

if (empty($_SESSION['smtp_relatorio_csrf'])) {
    $_SESSION['smtp_relatorio_csrf'] = bin2hex(random_bytes(32));
}

$resultado = null;
$destinatario = 'rianacleysla@gmail.com';
$detalheResultado = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destinatario = strtolower(trim($_POST['destinatario'] ?? ''));
    $csrfEnviado = $_POST['csrf_token'] ?? '';

    if (!is_string($csrfEnviado) || !hash_equals($_SESSION['smtp_relatorio_csrf'], $csrfEnviado)) {
        $resultado = false;
        $detalheResultado = 'A sessão do formulário expirou. Atualize a página e tente novamente.';
    } elseif (!$smtpConfigurado) {
        $resultado = false;
        $detalheResultado = 'A configuração SMTP está incompleta ou inválida. Revise smtp.local.php.';
    } elseif (!filter_var($destinatario, FILTER_VALIDATE_EMAIL)) {
        $resultado = false;
        $detalheResultado = 'Informe um endereço de e-mail válido para receber o teste.';
    } else {
        $arquivoPdf = null;
        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->getSMTPInstance()->Timelimit = 10;
            $mail->Host = $smtpHost;
            $mail->SMTPAuth = true;
            $mail->Timeout = 15;
            $mail->Username = $smtpUsuario;
            $mail->Password = $smtpSenha;
            $mail->SMTPSecure = $smtpCriptografia;
            $mail->Port = $smtpPorta;
            $mail->CharSet = 'UTF-8';
            $mail->setFrom($smtpRemetente, 'Unistore');
            $mail->addAddress($destinatario);
            $mail->isHTML(true);
            $mail->Subject = 'Relatório de e-mail - Unistore';
            $mail->Body = '<p>Este e-mail inclui o relatório de configuração e teste do servidor SMTP da Unistore em formato PDF.</p>';
            $mail->AltBody = 'Este e-mail inclui o relatório de configuração e teste do servidor SMTP da Unistore em formato PDF.';
            $arquivoPdf = gerarRelatorioPdf(
                $smtpHost,
                $smtpPorta,
                $smtpCriptografia,
                $smtpRemetente,
                $smtpConfigurado,
                null,
                '',
                $destinatario
            );
            $mail->addAttachment($arquivoPdf, 'relatorio-email-unistore.pdf', 'base64', 'application/pdf');
            $mail->send();
            $resultado = true;
            $detalheResultado = 'O servidor SMTP aceitou o envio da mensagem de teste.';
        } catch (Throwable $erroEmail) {
            $resultado = false;
            $detalheResultado = isset($mail) && $mail->ErrorInfo !== ''
                ? $mail->ErrorInfo
                : $erroEmail->getMessage();
            error_log('Falha no teste SMTP da Unistore: ' . $detalheResultado);
        } finally {
            if (is_string($arquivoPdf) && is_file($arquivoPdf)) {
                unlink($arquivoPdf);
            }
        }
    }
}

function escapar(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de e-mail | Unistore</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            padding: 40px 20px;
            background: #fff7fb;
            color: #8b3a62;
            font-family: 'Poppins', sans-serif;
        }
        .relatorio-container {
            width: min(100%, 900px);
            margin: 0 auto;
            padding: 30px;
            border-radius: 20px;
            background: #fff;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .15);
        }
        h1, h2 { font-family: 'Cinzel', serif; text-align: center; }
        h1 { margin: 0 0 8px; }
        h2 { margin: 28px 0 10px; font-size: 22px; }
        .subtitulo { margin: 0; color: #6a4251; text-align: center; }
        .resumo-box {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin: 25px 0;
        }
        .card {
            min-width: 0;
            padding: 18px 12px;
            border: 1px solid #f8c8dc;
            border-radius: 16px;
            background: #fffafc;
            text-align: center;
        }
        .card h3 { margin: 0 0 8px; font-size: 13px; text-transform: uppercase; }
        .valor { color: #d63384; font-size: 17px; font-weight: 600; overflow-wrap: anywhere; }
        .status-ok { color: #176b4a; }
        .status-erro { color: #c2186a; }
        .teste-container { padding: 22px; border: 1px solid #f8c8dc; border-radius: 16px; background: #fffafc; }
        .teste-container h2 { margin-top: 0; }
        .teste-intro { margin: 0 0 18px; color: #6a4251; text-align: center; }
        .form-teste { display: flex; align-items: end; justify-content: center; gap: 12px; }
        .campo-email { flex: 1; min-width: 0; }
        .campo-email label { display: block; margin-bottom: 7px; font-size: 13px; font-weight: 600; }
        .campo-email input {
            width: 100%;
            min-height: 44px;
            padding: 10px 12px;
            border: 1px solid #f8c8dc;
            border-radius: 12px;
            color: #5c2a44;
            font: inherit;
        }
        .campo-email input:focus { outline: 2px solid rgba(214, 51, 132, .2); border-color: #d63384; }
        .btn {
            display: inline-block;
            min-height: 44px;
            padding: 11px 20px;
            border: 0;
            border-radius: 25px;
            background: #d63384;
            color: #fff;
            font: inherit;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
            cursor: pointer;
        }
        .btn:hover { background: #c2186a; }
        .btn.secundario { background: #fce4ef; color: #8b3a62; }
        .resultado {
            margin-top: 20px;
            padding: 14px;
            border: 1px solid;
            border-radius: 12px;
            line-height: 1.5;
            overflow-wrap: anywhere;
        }
        .resultado.sucesso { border-color: #86efac; background: #f0fdf4; color: #166534; }
        .resultado.erro { border-color: #f8c8dc; background: #fff1f5; color: #c2186a; }
        .acoes { display: flex; justify-content: center; margin-top: 22px; }
        .rodape { margin-top: 18px; color: #a14d78; font-size: 12px; line-height: 1.5; text-align: center; }
        @media (max-width: 600px) {
            body { padding: 20px 12px; }
            .relatorio-container { padding: 22px 16px; }
            .resumo-box { grid-template-columns: 1fr; }
            .form-teste { align-items: stretch; flex-direction: column; }
        }
    </style>
</head>
<body>
    <main class="relatorio-container">
        <h1>Relatório de e-mail</h1>
        <p class="subtitulo">Resumo da configuração SMTP e do teste de envio da Unistore</p>

        <section class="resumo-box" aria-label="Resumo da configuração SMTP">
            <article class="card">
                <h3>Servidor SMTP</h3>
                <div class="valor"><?= escapar($smtpHost !== '' ? $smtpHost : 'Não informado') ?></div>
            </article>
            <article class="card">
                <h3>Porta SMTP</h3>
                <div class="valor"><?= $smtpPorta > 0 ? (string) $smtpPorta : 'Não informada' ?></div>
            </article>
            <article class="card">
                <h3>Criptografia</h3>
                <div class="valor"><?= escapar($smtpCriptografia !== '' ? strtoupper($smtpCriptografia) : 'Não informada') ?></div>
            </article>
            <article class="card">
                <h3>Remetente</h3>
                <div class="valor"><?= escapar($smtpRemetente !== '' ? $smtpRemetente : 'Não informado') ?></div>
            </article>
            <article class="card">
                <h3>Autenticação SMTP</h3>
                <div class="valor <?= $smtpUsuario !== '' && $smtpSenha !== '' ? 'status-ok' : 'status-erro' ?>">
                    <?= $smtpUsuario !== '' && $smtpSenha !== '' ? 'Credenciais preenchidas' : 'Credenciais ausentes' ?>
                </div>
            </article>
            <article class="card">
                <h3>Status da configuração</h3>
                <div class="valor <?= $smtpConfigurado ? 'status-ok' : 'status-erro' ?>">
                    <?= $smtpConfigurado ? 'Configurada' : 'Incompleta' ?>
                </div>
            </article>
        </section>

        <section class="teste-container">
            <h2>Teste de envio</h2>
            <p class="teste-intro">Envie o relatório de configuração SMTP em PDF para o e-mail informado.</p>
            <form class="form-teste" method="post">
                <input type="hidden" name="csrf_token" value="<?= escapar($_SESSION['smtp_relatorio_csrf']) ?>">
                <div class="campo-email">
                    <label for="destinatario">E-mail para receber o relatório</label>
                    <input
                        id="destinatario"
                        name="destinatario"
                        type="email"
                        maxlength="254"
                        autocomplete="email"
                        required
                        value="<?= escapar($destinatario) ?>"
                    >
                </div>
                <button class="btn" type="submit">Enviar relatório no e-mail</button>
            </form>
        </section>

        <?php if ($resultado !== null): ?>
            <div class="resultado <?= $resultado ? 'sucesso' : 'erro' ?>" role="status" aria-live="polite">
                <strong><?= $resultado ? 'E-mail enviado' : 'Falha no envio' ?></strong><br>
                <?= escapar($detalheResultado) ?>
                <?php if ($resultado): ?>
                    <br>Destinatário: <?= escapar($destinatario) ?> · Porta utilizada: <?= $smtpPorta ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <p class="rodape">A confirmação indica que o servidor SMTP aceitou a mensagem; ela não confirma a entrega na caixa de entrada. Senhas e credenciais não são exibidas.</p>
        <div class="acoes">
            <a class="btn secundario" href="painel.php">Voltar ao painel</a>
        </div>
    </main>
</body>
</html>