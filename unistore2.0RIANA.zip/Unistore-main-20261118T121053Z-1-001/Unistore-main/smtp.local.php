<?php
return [
    'host' => 'smtp.gmail.com',
    'username' => 'jacintojogo@gmail.com',
    'password' => 'pfizwnsikzbcmkgt',
    'from' => 'jacintojogo@gmail.com',
    'port' => 465,
    'secure' => 'ssl',
];