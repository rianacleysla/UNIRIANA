<?php

use Dompdf\Dompdf;
use Dompdf\Options;

function gerarRelatorioPdf(
    string $smtpHost,
    int $smtpPorta,
    string $smtpCriptografia,
    string $smtpRemetente,
    bool $smtpConfigurado,
    ?bool $resultadoEnvio = null,
    string $detalheEnvio = '',
    string $destinatario = ''
): string {
    $opcoes = new Options();
    $opcoes->set('isRemoteEnabled', false);
    $opcoes->set('defaultFont', 'DejaVu Sans');

    $dompdf = new Dompdf($opcoes);
    $data = date('d/m/Y H:i:s');

    $html = '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><style>
        @page { margin: 28px; }
        body { font-family: "DejaVu Sans", sans-serif; color: #8b3a62; font-size: 12px; background: #fff7fb; }
        .container { padding: 24px; border: 1px solid #f8c8dc; border-radius: 12px; background: #fff; }
        h1, h2 { font-family: "DejaVu Serif", serif; text-align: center; }
        h1 { margin: 0 0 8px; color: #8b3a62; font-size: 24px; }
        h2 { margin: 24px 0 12px; font-size: 17px; }
        .subtitulo { margin: 0 0 20px; color: #6a4251; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; background: #fffafc; }
        th, td { border: 1px solid #f8c8dc; padding: 10px; text-align: left; overflow-wrap: anywhere; }
        th { width: 38%; background: #fce4ef; color: #8b3a62; }
        .rodape { margin-top: 20px; color: #a14d78; font-size: 10px; text-align: right; }
    </style></head><body><div class="container">
        <h1>Relatório de e-mail</h1>
        <div class="subtitulo">Diagnóstico SMTP da Unistore · Gerado em ' . htmlspecialchars($data, ENT_QUOTES, 'UTF-8') . '</div>
        <table>
            <tr><th>Servidor SMTP</th><td>' . htmlspecialchars($smtpHost ?: 'Não informado', ENT_QUOTES, 'UTF-8') . '</td></tr>
            <tr><th>Porta SMTP</th><td>' . $smtpPorta . '</td></tr>
            <tr><th>Criptografia</th><td>' . htmlspecialchars(strtoupper($smtpCriptografia), ENT_QUOTES, 'UTF-8') . '</td></tr>
            <tr><th>Remetente</th><td>' . htmlspecialchars($smtpRemetente ?: 'Não informado', ENT_QUOTES, 'UTF-8') . '</td></tr>
            ' . ($destinatario !== '' ? '<tr><th>Destinatário</th><td>' . htmlspecialchars($destinatario, ENT_QUOTES, 'UTF-8') . '</td></tr>' : '') . '
            <tr><th>Status da configuração</th><td>' . ($smtpConfigurado ? 'Configurada' : 'Incompleta') . '</td></tr>
        </table>
        <div class="rodape">Senhas e credenciais não são exibidas neste relatório.</div>
    </div></body></html>';

    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    $arquivoTemp = tempnam(sys_get_temp_dir(), 'unistore-relatorio-');
    if ($arquivoTemp === false) {
        throw new RuntimeException('Nao foi possivel criar o arquivo temporario do PDF.');
    }
    file_put_contents($arquivoTemp, $dompdf->output());
    return $arquivoTemp;
}
