<?php
session_start();

require __DIR__ . '/conexao.php';
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mensagem = '';
$classe = '';

function garantirColunasResetSenha($conexao)
{
    $resultado = mysqli_query($conexao, "SHOW COLUMNS FROM cadastro LIKE 'reset_token'");
    if (mysqli_num_rows($resultado) === 0) {
        mysqli_query($conexao, "ALTER TABLE cadastro ADD COLUMN reset_token VARCHAR(255) NULL AFTER senha");
    }

    $resultado = mysqli_query($conexao, "SHOW COLUMNS FROM cadastro LIKE 'reset_expira_em'");
    if (mysqli_num_rows($resultado) === 0) {
        mysqli_query($conexao, "ALTER TABLE cadastro ADD COLUMN reset_expira_em DATETIME NULL AFTER reset_token");
    }
}

garantirColunasResetSenha($conexao);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recuperar'])) {
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Informe um e-mail válido.';
        $classe = 'erro';
    } else {
        $stmt = mysqli_prepare(
            $conexao,
            "SELECT nome, `email/tel` FROM cadastro WHERE LOWER(TRIM(`email/tel`)) = LOWER(?) LIMIT 1"
        );

        if (!$stmt) {
            $mensagem = 'Não foi possível verificar o e-mail informado.';
            $classe = 'erro';
        } else {
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $nome, $emailCadastrado);
            $usuarioEncontrado = mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            if ($usuarioEncontrado) {
                $token = bin2hex(random_bytes(32));
                $expiraEm = date('Y-m-d H:i:s', strtotime('+30 minutes'));

                $update = mysqli_prepare(
                    $conexao,
                    "UPDATE cadastro SET reset_token = ?, reset_expira_em = ? WHERE LOWER(TRIM(`email/tel`)) = LOWER(?) LIMIT 1"
                );

                if ($update) {
                    mysqli_stmt_bind_param($update, 'sss', $token, $expiraEm, $email);
                    mysqli_stmt_execute($update);
                    mysqli_stmt_close($update);
                }

                $baseUrl = 'http://localhost/Unistore%20-%20FINAL%20(1)/Unistore%20-%20FINAL%20/Unistore-main';
                $link = $baseUrl . '/redefinir_senha.php?token=' . urlencode($token);

                $mail = new PHPMailer(true);

                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'lianeivaribeiro@gmail.com';
                    $mail->Password = 'kukpjgyjotspgueo';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;
                    $mail->CharSet = 'UTF-8';

                    $mail->setFrom('lianeivaribeiro@gmail.com', 'Unistore');
                    $mail->addAddress($email, $nome ?: 'Cliente');
                    $mail->isHTML(true);
                    $mail->Subject = 'Recuperação de senha - Unistore';
                    $mail->Body = '<p>Olá, ' . htmlspecialchars($nome ?: 'cliente') . '.</p>'
                        . '<p>Recebemos sua solicitação para redefinir sua senha.</p>'
                        . '<p><a href="' . htmlspecialchars($link) . '">Clique aqui para redefinir sua senha</a></p>'
                        . '<p>Esse link expira em 30 minutos.</p>'
                        . '<p>Se você não solicitou isso, ignore este e-mail.</p>';

                    $mail->send();

                    $mensagem = 'Se o e-mail estiver cadastrado, uma mensagem foi enviada com instruções para redefinir sua senha.';
                    $classe = 'sucesso';
                } catch (Exception $e) {
                    $mensagem = 'Não foi possível enviar o e-mail no momento. Tente novamente mais tarde.';
                    $classe = 'erro';
                }
            } else {
                $mensagem = 'Se o e-mail estiver cadastrado, uma mensagem foi enviada com instruções para redefinir sua senha.';
                $classe = 'sucesso';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alterar Senha</title>
<style>
    *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI', sans-serif;}
    body{background:linear-gradient(135deg,#ffe6f2,#ffd6eb);display:flex;justify-content:center;align-items:center;min-height:100vh;}
    .container{width:min(480px, 90vw);background:#fff;padding:35px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.15);text-align:center;}
    .logo{display:block;margin:0 auto 15px auto;width:250px;height:auto;}
    h2{color:#8b3a62;margin-bottom:18px;}
    form{display:flex;flex-direction:column;gap:12px;text-align:left;}
    label{color:#8b3a62;font-weight:600;}
    input{padding:12px;border-radius:12px;border:1px solid #f8c8dc;outline:none;transition:0.3s;}
    input:focus{border-color:#d63384;box-shadow:0 0 8px rgba(214,51,132,0.3);}
    .mensagem{padding:15px;border-radius:12px;font-weight:bold;margin:15px 0;border:1px solid transparent;}
    .sucesso{background:#fce4ef;color:#8b3a62;border-color:#f8c8dc;}
    .erro{background:#ffe5e5;color:#b22222;border-color:#ffb6b6;}
    button, .botao{margin-top:10px;padding:12px 25px;border:none;border-radius:25px;background:#d63384;color:white;font-weight:bold;cursor:pointer;transition:0.3s;text-decoration:none;display:inline-block;text-align:center;}
    button:hover, .botao:hover{background:#c2186a;transform:scale(1.03);}
    .voltar{margin-top:20px;}
</style>
</head>
<body>
<div class="container">
    <img src="logo.png" alt="Logo" class="logo">
    <h2>RECUPERAÇÃO DE SENHA</h2>

    <form method="POST">
        <label for="email">E-mail cadastrado:</label>
        <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>
        <button type="submit" name="recuperar">Enviar instruções</button>
    </form>

    <?php if (!empty($mensagem)): ?>
        <div class="mensagem <?php echo $classe; ?>"><?php echo htmlspecialchars($mensagem); ?></div>
    <?php endif; ?>

    <div class="voltar">
        <a href="login.php" class="botao">Voltar para o Login</a>
    </div>
</div>
</body>
</html>