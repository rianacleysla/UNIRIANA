<?php
session_start();

include __DIR__ . '/conexao.php';

$mensagem = '';
$classe = '';
$token = trim($_GET['token'] ?? '');

function usuarioComTokenValido($conexao, $token)
{
    $stmt = mysqli_prepare(
        $conexao,
        "SELECT nome, `email/tel` FROM cadastro WHERE reset_token = ? AND reset_expira_em > NOW() LIMIT 1"
    );

    if (!$stmt) {
        return null;
    }

    mysqli_stmt_bind_param($stmt, 's', $token);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $nome, $email);
    $encontrado = mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return $encontrado ? ['nome' => $nome, 'email' => $email] : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['redefinir'])) {
    $token = trim($_POST['token'] ?? '');
    $novaSenha = $_POST['nova_senha'] ?? '';
    $confirmarSenha = $_POST['confirmar_senha'] ?? '';

    if ($token === '') {
        $mensagem = 'Token inválido ou expirado.';
        $classe = 'erro';
    } elseif ($novaSenha !== $confirmarSenha) {
        $mensagem = 'As senhas não conferem.';
        $classe = 'erro';
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $novaSenha)) {
        $mensagem = 'A senha deve ter pelo menos 8 caracteres, incluindo letra maiúscula, minúscula, número e símbolo.';
        $classe = 'erro';
    } else {
        $usuario = usuarioComTokenValido($conexao, $token);

        if (!$usuario) {
            $mensagem = 'Esse link expirou ou é inválido.';
            $classe = 'erro';
        } else {
            $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
            $update = mysqli_prepare(
                $conexao,
                "UPDATE cadastro SET senha = ?, reset_token = NULL, reset_expira_em = NULL WHERE reset_token = ? LIMIT 1"
            );

            if ($update) {
                mysqli_stmt_bind_param($update, 'ss', $senhaHash, $token);
                mysqli_stmt_execute($update);
                mysqli_stmt_close($update);
            }

            $mensagem = 'Senha alterada com sucesso! Faça login com sua nova senha.';
            $classe = 'sucesso';
            $token = '';
        }
    }
}

$usuario = $token ? usuarioComTokenValido($conexao, $token) : null;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Redefinir Senha</title>
<style>
    *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI', sans-serif;}
    body{background:linear-gradient(135deg,#ffe6f2,#ffd6eb);display:flex;justify-content:center;align-items:center;min-height:100vh;}
    .container{width:min(500px, 90vw);background:#fff;padding:35px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.15);}
    .logo{display:block;margin:0 auto 15px;width:250px;height:auto;}
    h2{text-align:center;color:#8b3a62;margin-bottom:20px;}
    form{display:flex;flex-direction:column;gap:12px;}
    label{color:#8b3a62;font-weight:600;}
    input{padding:12px;border-radius:12px;border:1px solid #f8c8dc;outline:none;transition:0.3s;}
    input:focus{border-color:#d63384;box-shadow:0 0 8px rgba(214,51,132,0.3);}
    .mensagem{padding:15px;border-radius:12px;font-weight:bold;margin:15px 0;text-align:center;}
    .sucesso{background:#fce4ef;color:#8b3a62;border:1px solid #f8c8dc;}
    .erro{background:#ffe5e5;color:#b22222;border:1px solid #ffb6b6;}
    button, .botao{margin-top:10px;padding:12px 25px;border:none;border-radius:25px;background:#d63384;color:white;font-weight:bold;cursor:pointer;transition:0.3s;text-decoration:none;display:inline-block;text-align:center;}
    button:hover, .botao:hover{background:#c2186a;transform:scale(1.03);}
    .voltar{text-align:center;margin-top:18px;}
</style>
</head>
<body>
<div class="container">
    <img src="logo.png" alt="Logo" class="logo">
    <h2>REDEFINIR SENHA</h2>

    <?php if (!empty($mensagem)): ?>
        <div class="mensagem <?php echo $classe; ?>"><?php echo htmlspecialchars($mensagem); ?></div>
    <?php endif; ?>

    <?php if ($usuario && $token !== ''): ?>
        <form method="POST">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            <label for="nova_senha">Nova senha:</label>
            <input type="password" id="nova_senha" name="nova_senha" required>
            <label for="confirmar_senha">Confirmar nova senha:</label>
            <input type="password" id="confirmar_senha" name="confirmar_senha" required>
            <button type="submit" name="redefinir">Salvar nova senha</button>
        </form>
    <?php else: ?>
        <div class="voltar">
            <a href="login.php" class="botao">Voltar para o Login</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
